package id.tokodurian.kasir;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class KasirFirebaseMessagingService extends FirebaseMessagingService {
    private static final String CHANNEL_ID = "kasir_durian_updates";

    @Override
    public void onMessageReceived(RemoteMessage message) {
        String title = "Kasir Durian";
        String body = "Ada pembaruan transaksi.";
        if (message.getNotification() != null) {
            if (message.getNotification().getTitle() != null) title = message.getNotification().getTitle();
            if (message.getNotification().getBody() != null) body = message.getNotification().getBody();
        }
        if (message.getData() != null) {
            if (message.getData().containsKey("title")) title = message.getData().get("title");
            if (message.getData().containsKey("body")) body = message.getData().get("body");
        }
        showNotification(title, body);
    }

    @Override
    public void onNewToken(String token) {
        // Token is registered after the cashier signs in through the app's WebView.
    }

    private void showNotification(String title, String body) {
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Transaksi Kasir Durian", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Pemberitahuan pemasukan dan pengeluaran baru");
            manager.createNotificationChannel(channel);
        }
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title == null ? "Kasir Durian" : title)
                .setContentText(body == null ? "Ada pembaruan transaksi." : body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body == null ? "Ada pembaruan transaksi." : body))
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build();
        manager.notify((int) (System.currentTimeMillis() & 0x7fffffff), notification);
    }
}

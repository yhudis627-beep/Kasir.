package id.tokodurian.kasir;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.content.pm.PackageManager;
import android.view.View;
import android.view.Window;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private static final String CHANNEL_ID = "kasir_durian_updates";
    private static final int NOTIFICATION_PERMISSION_REQUEST = 501;

    public class AndroidNotifier {
        @JavascriptInterface
        public void notify(String title, String message) {
            runOnUiThread(() -> showLocalNotification(title, message));
        }

        @JavascriptInterface
        public void registerFcmToken(String uid) {
            if (uid == null || uid.trim().isEmpty()) return;
            FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
                if (!task.isSuccessful() || task.getResult() == null || webView == null) return;
                String js = "window.onFcmTokenReceived(" + JSONObject.quote(uid) + "," + JSONObject.quote(task.getResult()) + ");";
                runOnUiThread(() -> webView.evaluateJavascript(js, null));
            });
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Transaksi Kasir Durian", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Pemberitahuan pemasukan dan pengeluaran baru");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
        }
    }

    private void showLocalNotification(String title, String message) {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? new Notification.Builder(this, CHANNEL_ID)
            : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title == null ? "Kasir Durian" : title)
            .setContentText(message == null ? "Ada pembaruan transaksi." : message)
            .setStyle(new Notification.BigTextStyle().bigText(message == null ? "Ada pembaruan transaksi." : message))
            .setAutoCancel(true);
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify((int) (System.currentTimeMillis() & 0x7fffffff), builder.build());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(android.graphics.Color.rgb(23, 77, 50));
        window.setNavigationBarColor(android.graphics.Color.rgb(23, 77, 50));
        createNotificationChannel();
        requestNotificationPermissionIfNeeded();
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(243, 246, 242));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        webView.addJavascriptInterface(new AndroidNotifier(), "AndroidNotifier");
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}

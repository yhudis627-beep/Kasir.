KASIR DURIAN - SUMBER APK v1.6

Perubahan v1.6:
1. Penjualan memakai kuantitas dan harga total item, bukan harga per buah.
2. Notifikasi penjualan/pengeluaran dapat ditekan untuk membuka aplikasi dan menampilkan detail transaksi terkait.
3. Firebase, riwayat, laporan, dan data lama tetap dipertahankan.

Build melalui GitHub Actions:
- Letakkan file ini di repository dengan nama KasirDurianAndroid-source.zip.
- Jalankan workflow Build Kasir Durian APK (workflow_dispatch).
- Unduh artifact Kasir-Durian-APK setelah workflow selesai.

PENTING: Jangan menghapus database Firebase. APK ini memakai project Firebase yang sama.

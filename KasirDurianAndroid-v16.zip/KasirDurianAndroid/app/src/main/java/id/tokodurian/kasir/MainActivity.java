package id.tokodurian.kasir;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.content.pm.PackageManager;
import android.view.Window;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private static final String CHANNEL_ID = "kasir_durian_updates";
    private static final int NOTIFICATION_PERMISSION_REQUEST = 501;
    private String pendingType = "";
    private String pendingRecordId = "";

    public class AndroidNotifier {
        @JavascriptInterface
        public void notify(String title, String message, String type, String recordId) {
            runOnUiThread(() -> showLocalNotification(title, message, type, recordId));
        }

        @JavascriptInterface
        public void registerFcmToken(String uid) {
            if (uid == null || uid.trim().isEmpty()) return;
            FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
                if (!task.isSuccessful() || task.getResult() == null || webView == null) return;
                String js = "window.onFcmTokenReceived(" + JSONObject.quote(uid) + "," + JSONObject.quote(task.getResult()) + ");";
                runOnUiThread(() -> webView.evaluateJavascript(js, null));
            });
        }

        @JavascriptInterface
        public String consumePendingNotification() {
            synchronized (MainActivity.this) {
                if (pendingType.isEmpty() || pendingRecordId.isEmpty()) return "";
                JSONObject obj = new JSONObject();
                try {
                    obj.put("type", pendingType);
                    obj.put("id", pendingRecordId);
                } catch (Exception ignored) { return ""; }
                pendingType = "";
                pendingRecordId = "";
                return obj.toString();
            }
        }
    }

    private void saveNotificationTarget(Intent intent) {
        if (intent == null) return;
        String type = intent.getStringExtra("notification_type");
        if (type == null) type = intent.getStringExtra("type");
        String id = intent.getStringExtra("notification_id");
        if (id == null) id = intent.getStringExtra("recordId");
        if (type != null && id != null && !type.isEmpty() && !id.isEmpty()) {
            synchronized (this) {
                pendingType = type;
                pendingRecordId = id;
            }
        }
    }

    private PendingIntent notificationPendingIntent(String type, String recordId) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra("notification_type", type == null ? "" : type);
        intent.putExtra("notification_id", recordId == null ? "" : recordId);
        int requestCode = (type + ":" + recordId).hashCode();
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getActivity(this, requestCode, intent, flags);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Transaksi Kasir Durian", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Pemberitahuan pemasukan dan pengeluaran baru");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
        }
    }

    private void showLocalNotification(String title, String message, String type, String recordId) {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? new Notification.Builder(this, CHANNEL_ID)
            : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title == null ? "Kasir Durian" : title)
            .setContentText(message == null ? "Ada pembaruan transaksi." : message)
            .setStyle(new Notification.BigTextStyle().bigText(message == null ? "Ada pembaruan transaksi." : message))
            .setContentIntent(notificationPendingIntent(type, recordId))
            .setAutoCancel(true);
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify((int) (System.currentTimeMillis() & 0x7fffffff), builder.build());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        saveNotificationTarget(getIntent());
        Window window = getWindow();
        window.setStatusBarColor(android.graphics.Color.rgb(23, 77, 50));
        window.setNavigationBarColor(android.graphics.Color.rgb(23, 77, 50));
        createNotificationChannel();
        requestNotificationPermissionIfNeeded();
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(243, 246, 242));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        webView.addJavascriptInterface(new AndroidNotifier(), "AndroidNotifier");
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        saveNotificationTarget(intent);
        if (webView != null) webView.post(() -> webView.evaluateJavascript("if(typeof handlePendingNotification==='function')handlePendingNotification();", null));
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}

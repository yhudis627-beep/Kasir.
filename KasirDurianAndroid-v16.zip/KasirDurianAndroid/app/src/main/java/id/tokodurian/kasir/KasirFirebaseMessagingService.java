package id.tokodurian.kasir;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.content.Context;

import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class KasirFirebaseMessagingService extends FirebaseMessagingService {
    private static final String CHANNEL_ID = "kasir_durian_updates";

    @Override
    public void onMessageReceived(RemoteMessage message) {
        String title = "Kasir Durian";
        String body = "Ada pembaruan transaksi.";
        if (message.getNotification() != null) {
            if (message.getNotification().getTitle() != null) title = message.getNotification().getTitle();
            if (message.getNotification().getBody() != null) body = message.getNotification().getBody();
        }
        String type = "";
        String recordId = "";
        if (message.getData() != null) {
            if (message.getData().containsKey("title")) title = message.getData().get("title");
            if (message.getData().containsKey("body")) body = message.getData().get("body");
            type = message.getData().getOrDefault("type", "");
            recordId = message.getData().getOrDefault("recordId", "");
        }
        showNotification(title, body, type, recordId);
    }

    @Override
    public void onNewToken(String token) {
        // Token is registered after the cashier signs in through the app's WebView.
    }

    private PendingIntent notificationPendingIntent(String type, String recordId) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra("notification_type", type == null ? "" : type);
        intent.putExtra("notification_id", recordId == null ? "" : recordId);
        int requestCode = (type + ":" + recordId).hashCode();
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getActivity(this, requestCode, intent, flags);
    }

    private void showNotification(String title, String body, String type, String recordId) {
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Transaksi Kasir Durian", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Pemberitahuan pemasukan dan pengeluaran baru");
            manager.createNotificationChannel(channel);
        }
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title == null ? "Kasir Durian" : title)
                .setContentText(body == null ? "Ada pembaruan transaksi." : body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body == null ? "Ada pembaruan transaksi." : body))
                .setContentIntent(notificationPendingIntent(type, recordId))
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build();
        manager.notify((int) (System.currentTimeMillis() & 0x7fffffff), notification);
    }
}

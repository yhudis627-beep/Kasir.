KASIR DURIAN - PROYEK ANDROID

Isi proyek ini adalah sumber aplikasi Android (WebView) yang membungkus aplikasi kasir durian menjadi aplikasi Android.

CARA MEMBUAT APK:
1. Buka Android Studio di komputer.
2. Pilih Open, lalu pilih folder KasirDurian hasil ekstrak ZIP ini.
3. Tunggu Gradle Sync selesai. Komputer perlu internet saat pertama kali mengunduh Android Gradle Plugin dan Android SDK yang dibutuhkan.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK biasanya tersedia di app/build/outputs/apk/debug/app-debug.apk.
6. Pindahkan APK ke HP Android dan buka untuk memasang. Jika diminta, izinkan pemasangan aplikasi dari sumber tersebut.

CATATAN:
- Aplikasi kasir berjalan offline setelah terpasang.
- Riwayat transaksi disimpan di penyimpanan browser WebView pada perangkat itu.
- Jangan hapus data aplikasi sebelum mengekspor/mencadangkan laporan.
- File ini adalah proyek sumber, bukan APK siap-pasang. Lingkungan pembuatan saat ini tidak memiliki Android SDK/Gradle untuk menghasilkan APK yang sudah dikompilasi.
